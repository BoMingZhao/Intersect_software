#pragma once
#include <stack>
#include <vector>
#include <iostream>
#include "stdlib.h"
#include <ctime>
#include <string>  
using namespace std;

class Circle {
public:
	int m, n, r;
	Circle(int a, int b, int c);
	bool equal(Circle c);
};